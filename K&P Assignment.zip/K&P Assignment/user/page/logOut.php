<?php
require '../../_base.php';

// Simply call the logout function from _base.php
logout('login.php');